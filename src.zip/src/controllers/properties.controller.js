import pool from "../db.js";

// GET all properties with filtering & pagination
export const getProperties = async (req, res) => {
  try {
    const {
      location, status, property_type_id,
      transaction_type_id, page = 1, limit = 20,
      all, created_by
    } = req.query;

    let filters = [];
    let values = [];

    if (location) {
      values.push(`%${location}%`);
      filters.push(`p.location ILIKE $${values.length}`);
    }
    if (status) {
      values.push(status);
      filters.push(`p.status = $${values.length}`);
    }
    if (property_type_id) {
      values.push(property_type_id);
      filters.push(`p.property_type_id = $${values.length}`);
    }
    if (transaction_type_id) {
      values.push(transaction_type_id);
      filters.push(`p.transaction_type_id = $${values.length}`);
    }
    if (created_by) {
      values.push(created_by);
      filters.push(`p.created_by = $${values.length}`);
    }

    if (!all) {
      filters.push(`p.status = 'approved'`);
      filters.push(`(p.amenities->>'availability' IS NULL OR p.amenities->>'availability' != 'taken')`);
    }

    filters.push(`(p.featured_until IS NULL OR p.featured_until > NOW())`);
    filters.push("p.deleted_at IS NULL");

    const whereClause = filters.length ? `WHERE ${filters.join(" AND ")}` : "";
    const offset = (page - 1) * limit;

    const result = await pool.query(
      `SELECT p.*, u.is_agent_verified as agent_verified
       FROM properties p
       LEFT JOIN users u ON p.created_by = u.id
       ${whereClause}
       ORDER BY p.is_featured DESC, p.created_at DESC
       LIMIT $${values.length + 1} OFFSET $${values.length + 2}`,
      [...values, limit, offset]
    );

    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch properties" });
  }
};

// CREATE a new property
export const createProperty = async (req, res) => {
  try {
    const {
      title, description, location, address,
      bedrooms, bathrooms, square_footage,
      property_type_id, transaction_type_id,
      images, amenities, currency,
      mortgage_available, mortgage_rate, mortgage_term,
      latitude, longitude, country, district
    } = req.body;
    const created_by = req.user?.id;
    const result = await pool.query(
      `INSERT INTO properties
      (title, description, location, address, bedrooms, bathrooms, square_footage,
       property_type_id, transaction_type_id, created_by, images, amenities,
       currency, mortgage_available, mortgage_rate, mortgage_term,
       latitude, longitude, country, district, status, created_at, updated_at)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,'pending',NOW(),NOW())
      RETURNING *`,
      [
        title, description, location, address,
        bedrooms || null, bathrooms || null, square_footage || null,
        property_type_id, transaction_type_id,
        created_by,
        images || [],
        amenities || {},
        currency || 'UGX',
        mortgage_available || false,
        mortgage_rate || null,
        mortgage_term || null,
        latitude || null,
        longitude || null,
        country || 'Uganda',
        district || null,
      ]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ error: "Failed to insert property" });
  }
};

// UPDATE a property
export const updateProperty = async (req, res) => {
  const { id } = req.params;
  const { title, description, location, address, bedrooms, bathrooms, square_footage, country, district } = req.body;
  try {
    const result = await pool.query(
      `UPDATE properties
       SET title = COALESCE($1, title),
           description = COALESCE($2, description),
           location = COALESCE($3, location),
           address = COALESCE($4, address),
           bedrooms = COALESCE($5, bedrooms),
           bathrooms = COALESCE($6, bathrooms),
           square_footage = COALESCE($7, square_footage),
           country = COALESCE($8, country),
           district = COALESCE($9, district),
           updated_at = NOW()
       WHERE id = $10 AND deleted_at IS NULL
       RETURNING *`,
      [title, description, location, address, bedrooms, bathrooms, square_footage, country, district, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Property not found or deleted" });
    }

    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to update property" });
  }
};

// SOFT DELETE a property
export const deleteProperty = async (req, res) => {
  const { id } = req.params;

  try {
    const result = await pool.query(
      `UPDATE properties SET deleted_at = NOW()
       WHERE id = $1 AND deleted_at IS NULL
       RETURNING *`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Property not found or already deleted" });
    }

    res.json({ message: "Property deleted successfully" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to delete property" });
  }
};